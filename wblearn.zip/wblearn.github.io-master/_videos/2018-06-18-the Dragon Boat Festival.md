---
title: 端午节和家人在一起
youtube_id: 25402003
cover_id: img/videos_cover/a8a95fadfaed1509736a61a727b7b5effa0e21a5.jpg
date: 2018-06-18
tags: [端午节, vlog, 生活,wblearn,日常]
---
日常生活记录&&练习视频剪辑

视频首发[我的微博](http://weibo.com/wudalanggd)，欢迎关注。视频原地址戳下面：

* [ 端午节](https://www.bilibili.com/video/av25402003)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**