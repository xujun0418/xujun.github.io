---
title: comming home in August
youtube_id: 31777606
cover_id: img/videos_cover/bf2b80b66a31649ad480b66c5b39dc8cb35c088c.jpg
date: 2018-08-12
tags: [wblearn, home, August]
---
八月中旬回的老家处理事情，学到了很多，补发记录一下
