---
title: Wblearn Blog
youtube_id: 26157244
cover_id: img/videos_cover/106.jpg
date: 2018-07-4
tags: [wblearn, 博客, blog]
---
此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，而国内几乎所有的视频网站都有广告。

视频首发[我的微博](http://weibo.com/wudalanggd)，欢迎关注：)视频原地址戳下面：

* [Wblearn Blog](https://www.bilibili.com/video/av26157244)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**
